<?php 
session_start();
$emppid = $_SESSION['empid'];
 
require_once('db.php');

if (isset($_POST["id"])) {

	$id = $_POST["id"];

	$sql = "DELETE FROM `inc_deplocation` WHERE `deploc_id`=?";

$getut = "SELECT * FROM `inc_deplocation` WHERE deploc_id='$id'";
  $delut = mysqli_query($connection, $getut);
  while ($row = mysqli_fetch_array($delut)) 
  {
    $unit = $row["location"];
  }


$stmt = $db->prepare($sql);


    try {
      $stmt->execute([$id]);

      $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Department Unit Removed : $unit','$emppid')" ;
      mysqli_query($connection, $logsql);

      header('Location:../units.php?deleted');

      }

     catch (Exception $e) {
        $e->getMessage();
        echo "Error";
    }

}
else {
	header('Location:../units.php?del_error');
}

	

?>