<?php
session_start();
$emppid = $_SESSION['empid'];
 require_once('db.php');
  if (isset($_POST['submit'])) 
  {
      $locname = $_POST['locname'];
      $stip = $_POST['stip'];
      $edip = $_POST['edip'];
      
      //-- Insert Data Into DB --//
      $sql = "INSERT INTO `inc_locations`(`loc_name`, `st_ip`, `ed_ip`, `status`) VALUES ('$locname','$stip','$edip','1')";
      //-- Insert Data Into DB --//

     

      try {
       
        mysqli_query($connection, $sql); 

        $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('Location Created : $locname','$emppid')" ;
      mysqli_query($connection, $logsql);

        header('Location:../locations.php?success');

      }

       catch (Exception $e) {
          $e->getMessage();
          echo "Error";
      }
    }















?>
