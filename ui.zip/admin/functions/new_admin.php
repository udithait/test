<?php
 require_once('db.php');
 session_start();
  $emppid = $_SESSION['empid'];

  if (isset($_POST['submit'])) {
      $email = $_POST['email'];
      
      $cksql = "SELECT id FROM admin WHERE email = '$email'";
      $chkemail = mysqli_query($connection, $cksql);


      if (mysqli_num_rows($chkemail)>0) {
          // email already EXISTS
            echo "Oops...This email already exists!";
            die();
      }
      else {

        $password = password_hash($_POST['password'],PASSWORD_BCRYPT,array('cost'=>12));

      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                  $emailErr = "Invalid email format";
                  echo $emailErr;
                  die();
                  $email = $_POST['email'];
               }
               else {

               }
      //-- Get Employee Data --//
      $fname = $_POST['fname'];
      $lname = $_POST['lname'];
      $role = $_POST['role'];
      $location = $_POST['ulocation']; 
      $mobile = $_POST['mobile'];  
      $empid = $_POST['empid'];      

      //-- Insert Data Into DB --//
      $sql = "INSERT INTO admin (`email`, `password`, `fname`, `lname`, `role`,`empid`,`location`,`mobile`)
      VALUES ('$email', '$password', '$fname', '$lname', '$role','$empid','$location','$mobile')";
      
      $sql2 = "INSERT INTO `inc_email`(`empid`, `role`, `email`, `location`, `overdue`, `summary`, `duedays`, `freq`) VALUES ('$empid','$role','$email','$location','1','1','1','Daily')";

      //-- Insert Data Into DB --//

     

      try {
       
        mysqli_query($connection, $sql); 
        mysqli_query($connection, $sql2);

        $logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('New User Created : $empid','$emppid')" ;
      mysqli_query($connection, $logsql);

        header('Location:../users.php?success');

      }

       catch (Exception $e) {
          $e->getMessage();
          echo "Error";
      }


      }
      // END OF - CHECK IF EMPLOYEE EMAIL EXISTS //
      }
?>