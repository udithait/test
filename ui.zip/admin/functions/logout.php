<?php
session_start();
$empid = $_SESSION['empid'];

require_once('db.php');
$logsql = "INSERT INTO `inc_syslogs`(`logdes`, `user`) VALUES ('User Loged Out : $empid','$empid')" ;
mysqli_query($connection, $logsql);

unset($_SESSION['emapid']);
session_destroy();

header("Location: ../login.php");
exit;
?>