<?php 
 session_start();
 $empid="";
 $odnoti = "";
 $summary = "";
 $duedays = "";
 $freq = "";
    ob_start();
    require_once('functions/db.php');
    // If session variable is not set it will redirect to login page

    if(!isset($_SESSION['empid']) || empty($_SESSION['empid'])){

      header("location: login.php");

      exit;
    }
    else
    {
        $luser = $_SESSION['empid'];
        $glus = "SELECT * FROM `admin` WHERE `empid`='$luser'";
        $getluser = mysqli_query($connection, $glus);
        while ($ftuser = mysqli_fetch_array($getluser)) 
        {
            $lfname = $ftuser['fname'];
            $llname = $ftuser['lname'];
            $lrole = $ftuser['role'];
            $lemploc = $ftuser['location'];
            $lemail = $ftuser['email'];
        }

        if ($lrole == "QA" || $lrole == "Supervisor" ) 
        {
            header("location: index.php");
        }
    }

    $email = $_SESSION['empid'];

if (isset($_GET['empid'])) 
{
  $empid = mysqli_real_escape_string($connection, $_GET['empid']);
  
  $esql = "SELECT * FROM `inc_email` WHERE `empid`='$empid'";
  $getconfig = mysqli_query($connection, $esql);
  while ($erow = mysqli_fetch_array($getconfig)) 
  {
    $odnoti = $erow['overdue'];
    $summary = $erow['summary'];
    $duedays = $erow['duedays'];
    $freq = $erow['freq'];
  }
}

if (isset($_POST['save'])) 
{
    if (isset($_POST['odnoti'])) 
    {
      $godnoti = "1";
    }
    else
    {
      $godnoti = "0";
    }
    if (isset($_POST['summary'])) 
    {
      $gsummary = "1";
    }
    else
    {
      $gsummary = "0";
    }
    
    $gduedays = $_POST['duedays'];
    $gfreq = $_POST['freq'];

    $save = "UPDATE `inc_email` SET `overdue`='$godnoti',`summary`='$gsummary',`duedays`='$gduedays',`freq`='$gfreq' WHERE `empid`='$empid'";
    mysqli_query($connection, $save);
    header('Location:email-config.php?success');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/icon.png">
    <title>Email Config | Incident Management System</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style type="text/css">
    .sediv{display: none;}
    .opendiv
    {
        display: block;
        opacity: 0;
    animation: fadeIn 1s ease-in both;
    }

.hid{display: none;}
.sho{display: block;}

    /* The switch - the box around the slider */
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header"> <a class="navbar-toggle hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse"><i class="ti-menu"></i></a>
                <div class="top-left-part"><a class="logo" href="#"><b><img src="../plugins/images/icon.png" style="width: 90px; " alt="home" /></b></a></div>
                <ul class="nav navbar-top-links navbar-left hidden-xs">
                    <li><a href="javascript:void(0)" class="open-close hidden-xs waves-effect waves-light"><i class="icon-arrow-left-circle ti-menu"></i></a></li>
                    <li>
                        <form role="search" class="app-search hidden-xs">
                            <input type="text" placeholder="Search..." id="se" class="form-control"> <a href=""><i class="fa fa-search"></i></a> </form>
                    </li>
                </ul>
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <!-- /.dropdown -->
                    <!-- /.dropdown -->
                </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Left navbar-header -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" id="se" class="form-control" placeholder="Search..."> <span class="input-group-btn">
            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
            </span> </div>
                        <!-- /input-group -->
                    </li>
                    <li class="user-pro">
                        <a href="#" class="waves-effect"><img src="../plugins/images/user.jpg" alt="user-img" class="img-circle"> <span class="hide-menu"> Account<span class="fa arrow"></span></span>
                        </a>
                        <ul class="nav nav-second-level">
                            <li><a href="settings.php"><i class="ti-settings"></i> Account Setting</a></li>
                            <li><a href="functions/logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                        </ul>
                    </li>
                    <li class="nav-small-cap m-t-10"> Main Menu</li>
                    <li> <a href="admin-dash.php" class="waves-effect active"><i class="linea-icon linea-basic fa-fw" data-icon="v"></i> <span class="hide-menu"> Dashboard </a>
                    </li>
                    <li> <a href="#" class="waves-effect"><i data-icon="&#xe00b;" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Incident<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="new-incident.php">Add Incident</a></li>
                            <li><a href="inc-list.php">All Incident</a></li>
                            </li>
                        </ul>
                    </li>
                   <?php
                    if ($lrole=="Admin") 
                    {
                      echo '<li class="nav-small-cap"> Administrator </li>
                    <li> <a href="#" class="waves-effect"><i data-icon="H" class="linea-icon linea-basic fa-fw"></i> <span class="hide-menu">Access<span class="fa arrow"></span></span></a>
                        <ul class="nav nav-second-level">
                            <li><a href="users.php">Users</a></li>
                            <li><a href="locations.php">Locations</a></li>
                            <li><a href="dept.php">Departments</a></li>
                            <li><a href="units.php">Units</a></li>
                            <li><a href="types.php">Incident Types</a></li>
                            <li><a href="rating.php">Incident Ratings</a></li>
                            <li><a href="syslogs.php">System Logs</a></li>
                            <li><a href="email-config.php">Email Configuration</a></li>
                        </ul>
                    </li>';
                    }
                    ?>
                    <li><a href="functions/logout.php" class="waves-effect"><i class="icon-logout fa-fw"></i> <span class="hide-menu">Log out</span></a></li>
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title"><?php echo $lfname." ".$llname; ?></h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12"> 
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active"><a href="#">Email Config</a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!--------------- search ------------------------>
                <div id="adse" class="sediv container">
                    <form action="inc-list.php" method="get">
                            <div class="row">
                            <div class="col-sm-12" style="margin-top: 30px;">
                                <h3>Advanced Search</h3>
                                 <input type="text" name="words" class="form-control" placeholder="Type here to search" style="width: 70%; float: left;">
                                 <button type="submit" name="se" class="form-control btn btn-info" style="width: 20%">Search</button>
                                 </div>
                            </div>
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-sm-3">
                                <label>Period From</label>
                                <input type="date" class="form-control" name="fromdate">
                                </div>
                                <div class="col-sm-3">
                                <label>To</label>
                                <input type="date" class="form-control" name="todate">
                                </div>
                                <div class="col-sm-3">
                                </div>
                                <div class="col-sm-3">
                                </div>
                        </div>
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-sm-3">
                                    <label>Status</label> <br>
                                    <input type="checkbox" name="status[]" value=""> All <br>
                                    <input type="checkbox" name="status[]" value="Pending"> Pending <br>
                                    <input type="checkbox" name="status[]" value="Review"> Reviewing <br>
                                    <input type="checkbox" name="status[]" value="Hold"> Hold <br>
                                    <input type="checkbox" name="status[]" value="Reject"> Reject <br>
                                    <input type="checkbox" name="status[]" value="Completed"> Completed <br>  
                                </div>
                                <div class="col-sm-3">
                                    <label>Type</label> <br>
                                    <input type="checkbox" name="inctype[]" value=""> All <br>
                                    <?php
                                                      $gettyp = "SELECT * FROM `inc_types` ";
                                                      $get_tp = mysqli_query($connection, $gettyp);
                                                      while ($lst_tp = mysqli_fetch_array($get_tp)) {
                                                        echo '
                                    <input type="checkbox" name="inctype[]" value="'.$lst_tp['typ_name'].'"> '.$lst_tp['typ_name'].' <br>
                                    ';
                                    }
                                    ?>
                                </div>
                                <div class="col-sm-3">
                                    <label>Person Involved</label> <br>
                                    <input type="checkbox" name="incperson[]" value=""> All <br>
                                    <input type="checkbox" name="incperson[]" value="In Patient"> In Patient <br>
                                    <input type="checkbox" name="incperson[]" value="Out Patient"> Out Patient <br>
                                    <input type="checkbox" name="incperson[]" value="Visitor"> Visitor <br>
                                    <input type="checkbox" name="incperson[]" value="Staff Member"> Consultant/Staff Member <br>
                                    <input type="checkbox" name="incperson[]" value="Property/Process"> Property/Process <br>
                                </div>
                                <div class="col-sm-3">
                                    <label>Rating</label> <br>
                                    <input type="checkbox" name="routing[]" value=""> All <br>
                                    <?php
                                    $getrat = "SELECT * FROM `inc_rating`";
                                    $get_rat = mysqli_query($connection, $getrat);
                                    while ($lst_rat = mysqli_fetch_array($get_rat)) 
                                    {
                                        echo '<input type="checkbox" name="routing[]" value="'.$lst_rat["rat_name"].'"> '.$lst_rat["rat_name"].' <br>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="row" style="margin-top: 30px; margin-bottom: 60px;">
                                <div class="col-sm-3">
                                    <label>User</label>
                                                <select class="form-control" name="suser">
                                                      <option value="">-- Select User--</option>
                                                      <?php
                                                      $getuser = "SELECT * FROM `admin` ";
                                                      $get_user = mysqli_query($connection, $getuser);
                                                      while ($lst_user = mysqli_fetch_array($get_user)) {
                                                      echo '<option value="'.$lst_user["empid"].'">'.$lst_user["fname"]." ".$lst_user["lname"].'('.$lst_user["empid"].')</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Department</label>
                                                <select class="form-control" name="sdepart">
                                                      <option value="">-- Select Department--</option>
                                                      <?php
                                                      $getdpt = "SELECT * FROM `inc_depart` ";
                                                      $get_dpt = mysqli_query($connection, $getdpt);
                                                      while ($lst_dept = mysqli_fetch_array($get_dpt)) {
                                                      echo '<option value="'.$lst_dept["dpt_name"].'">'.$lst_dept["dpt_name"].'</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Location Occurred</label>
                                                <select class="form-control" name="slocation">
                                                      <option value="">-- Select Location--</option>
                                                      <?php
                                                      if ($lrole =="QA")
                                                      {
                                                            echo '<option value="'.$lemploc.'">'.$lemploc.'</option>';
                                                      }
                                                      else
                                                      {
                                                        $getoclc = "SELECT * FROM `inc_locations`";
                                                        $get_oclc = mysqli_query($connection, $getoclc);
                                                        while ($lst_oclc = mysqli_fetch_array($get_oclc)) {
                                                            echo '<option value="'.$lst_oclc["loc_name"].'">'.$lst_oclc["loc_name"].'</option>';
                                                            }
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                                <div class="col-sm-3">
                                    <label>Location Reported</label>
                                    <select class="form-control" name="srptlocation">
                                                      <option value="">-- Select Location--</option>
                                                      <?php
                                                      $getrplc = "SELECT * FROM `inc_locations`";
                                                      $get_rplc = mysqli_query($connection, $getrplc);
                                                      while ($lst_rplc = mysqli_fetch_array($get_rplc)) {
                                                      echo '<option value="'.$lst_rplc["loc_name"].'">'.$lst_rplc["loc_name"].'</option>';
                                                        }
                                                      ?>
                                                  </select>
                                </div>
                            </div>
                            </form>
                </div>
                <!-----------------end search ---------------->
                <!--.row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                          <?php
                  if (isset($_GET["success"])) {
                    echo 
                    '<div class="alert alert-success" >
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close"></a>
                                   <strong>DONE!! </strong><p> Email Settings Updated.</p>
                              </div>'
                    ;
                  }
                ?>
                            <h3 class="box-title m-b-0">Email Configuration</h3>
                            <p class="text-muted m-b-30 font-13"> Settings: </p>
                            <div class="row">
                                <div class="col-sm-12 col-xs-12">
                                    <form action="" method="post">
                                        <!-- <div class="form-group">
                                            <label for="exampleInputuname">User Name</label>
                                            <div class="input-group">
                                                <div class="input-group-addon"><i class="ti-user"></i></div>
                                                <input type="text" class="form-control" id="exampleInputuname" placeholder="Username"> </div>
                                        </div> -->
                                        <div class="form-group">
                                            <label for="dpname">User</label>
                                            <div class="input-group">
                                                 <select class="form-control" id="user" name="suser">
                                                      <option value="">-- Select User--</option>
                                                      <?php
                                                      $getuser = "SELECT * FROM `admin` ";
                                                      $get_user = mysqli_query($connection, $getuser);
                                                      while ($lst_user = mysqli_fetch_array($get_user)) {
                                                      echo '<option value="'.$lst_user["empid"].'"
                                                       '; if ($lst_user["empid"]==$empid) {echo "Selected";}
                                                       echo '>'.$lst_user["fname"]." ".$lst_user["lname"].'</option>';
                                                        }
                                                      ?>
                                                  </select>
                                                </div>
                                        </div>
                                        <div class="<?php if(isset($_GET['empid'])) {echo "shw";} else{echo "hid";}?>">
                                        <div class="form-group">
                                            <label for="dpname">Overdue Notification</label>
                                            <div class="input-group">
                                                 <!-- Rounded switch -->
                                                    <label class="switch">
                                                    <input value="1" name="odnoti" type="checkbox" <?php if ($odnoti == "1") {
                                                      echo "checked";
                                                    }?>>
                                                    <span class="slider round"></span>
                                                    </label>
                                                </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="dpname">Summary Email</label>
                                            <div class="input-group">
                                                 <!-- Rounded switch -->
                                                    <label class="switch">
                                                    <input value="1" name="summary" type="checkbox" <?php if ($summary == "1") {
                                                      echo "checked";
                                                    }?>>
                                                    <span class="slider round"></span>
                                                    </label>
                                                </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="dpname">Overdue After (Days)</label>
                                            <div class="input-group">
                                                 <input type="number" value="<?php echo $duedays; ?>" name="duedays" class="form-control">
                                                </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="dpname">Frequency</label>
                                            <div class="input-group">
                                                 <select name="freq" class="form-control">
                                                     <option value="">-- Select --</option>
                                                     <option value="Monthly" <?php if ($freq=="Monthly") {echo "Selected";}?>>Monthly</option>
                                                     <option value="Weekly" <?php if ($freq=="Weekly") {echo "Selected";}?>>Weekly</option>
                                                     <option value="Daily" <?php if ($freq=="Daily") {echo "Selected";}?>>Daily</option>
                                                 </select>
                                                </div>
                                        </div>
                                        
                                        
                                       
                                        <button type="submit" name="save" class="btn btn-success waves-effect waves-light m-r-10">Update</button>
                                      </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
           

                </div>
                <!--./row-->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> <?php echo date('Y'); ?> &copy; Hemas Hospitals. All Rights Reserved. </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <?php 
    mysqli_close($connection);
    ?>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/tether.min.js"></script>
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="js/jasny-bootstrap.js"></script>
    <!--Style Switcher -->
    <script src="../plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
    <!-- CHECK IF PASSWORDS MATCH -->
        <script>
                $(document).ready(function(){
                    $("#ConfirmPassword").keyup(function(){
                         if ($("#Password").val() != $("#ConfirmPassword").val()) {
                             $("#msg").html("Password do not match").css("color","red");
                         }else{
                             $("#msg").html("Password matched").css("color","green");
                        }
                  });
            });
            </script> 
    <!--END CHECK IF PASSWORDS MATCH -->
<script type="text/javascript">
$(document).ready(function(){
    $('#se').click(function() {
    $('#adse').toggleClass('opendiv');
    });
    });
</script>
<script type="text/javascript">
$(document).ready(function(){
    $('#user').change(function() {
        var suser = $('#user :selected').val();
        //alert(suser);
        window.location.replace("email-config.php?empid="+suser);
    });
    });
</script>
</body>
</html>